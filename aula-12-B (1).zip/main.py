import math
print( math.factorial(6))




#-------------------------------------------#

classe = {"ana": 4.5,
          "beatriz": 6.5
          "geraldo"; 1.0,
          "josé": 10.0
          "maria"; 9.0}
notas = classe.values()
media = sum(notas)/5
print("a media da classe é ",média)





dic = {"Salgados": 4.50,
      "Lanche": 6.50,
      "Suco": 3.00,
      "Refrigerante": 3.50,
      "Doce": 1.00}
print(dic)



#------------PRATICANDO DICIONARIO--------#
D = {"arroz": 17.30,"feijão": 12.50,"carne":23.90,"alface": 3.40}
print(D)

D["carne"] = 25.0
D["tomate"] = 8.80
print(D)
#---------PRATICANDO TUPLAS---------------#
T = (10,20,30,40,50)
a,b,c,d,e = T
print("a =",a,"b =",b)

print("d + e =",d+e)



#----------- PRATICANDO LISTA --------------#

L = [5, 7, 2, 9, 4, 1, 3,]
print("lista = ",L)
print("o tamanho da lista é ",len(L))
print("o maior elemento da lista é ",max(L))
print("o menor elemento da lista é ",min(L)) 
print("a soma dos elementos da lista é ",sum(L))
L.sort()
print("lista em ordem crescente: ",L)
L.reverse()
print("lista em ordem decrescente: ",L)





#-----------------------------------------------#

